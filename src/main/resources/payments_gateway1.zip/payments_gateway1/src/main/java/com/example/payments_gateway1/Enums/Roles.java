package com.example.payments_gateway1.Enums;

public enum Roles {
    USER,
    MERCHANT
}
