package com.example.payments_gateway1.Enums;

public enum TxnStatus {
    INITIATED,
    INPROGRESS,
    SUCCESSFUL,
    FAILED
}
