package com.example.payments_gateway1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentsGateway1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
